package com.example.demo.Entity;
import javax.persistence.*;

@Entity(name="pro")
public class Products {
    @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
    int productid;
    String bookname;
    String bookdesc;
    String bookimg;
    Double bookprize;

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getBookdesc() {
        return bookdesc;
    }

    public void setBookdesc(String bookdesc) {
        this.bookdesc = bookdesc;
    }

    public String getBookimg() {
        return bookimg;
    }

    public void setBookimg(String bookimg) {
        this.bookimg = bookimg;
    }

    public Double getBookprize() {
        return bookprize;
    }

    public void setBookprize(Double bookprize) {
        this.bookprize = bookprize;
    }
}
