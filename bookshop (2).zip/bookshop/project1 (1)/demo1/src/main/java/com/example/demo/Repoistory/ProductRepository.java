package com.example.demo.Repoistory;

import java.util.List;

import com.example.demo.Entity.Products;

import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Products, Integer> {

    public List<Products> findAll();
}
